package com.jarvis.offline

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Groq sohbet istemcisi. Token tüketimini düşük tutmak için:
 *  - kısa sistem mesajı, en fazla [MAX_TOKENS] cevap tokenı
 *  - sadece son [HISTORY] mesaj gönderilir
 * API anahtarı koda gömülmez; uygulamada girilir ve telefonda saklanır.
 */
class GroqClient(context: Context) {

    private val prefs = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("groq_key", "") ?: ""
        set(v) = prefs.edit().putString("groq_key", v.trim()).apply()

    var model: String
        get() = prefs.getString("groq_model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = prefs.edit().putString("groq_model", v.trim().ifBlank { DEFAULT_MODEL }).apply()

    val hasKey: Boolean get() = apiKey.isNotBlank()

    private val history = ArrayList<Pair<String, String>>() // (role, content)

    suspend fun ask(prompt: String): String = withContext(Dispatchers.IO) {
        if (!hasKey) return@withContext "Önce Groq API anahtarını girmelisiniz efendim."

        history += "user" to prompt
        while (history.size > HISTORY) history.removeAt(0)

        val messages = JSONArray().put(
            JSONObject().put("role", "system").put("content", SYSTEM_PROMPT)
        )
        history.forEach { (r, c) -> messages.put(JSONObject().put("role", r).put("content", c)) }

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("max_tokens", MAX_TOKENS)
            .put("temperature", 0.7)

        val conn = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            if (code !in 200..299) {
                history.removeAt(history.lastIndex)
                return@withContext when (code) {
                    401 -> "API anahtarı geçersiz görünüyor efendim."
                    429 -> "Groq kullanım limiti doldu, biraz bekleyelim."
                    else -> "Groq hatası ($code)."
                }
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val answer = JSONObject(text)
                .getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
            history += "assistant" to answer
            answer
        } catch (e: java.io.IOException) {
            history.removeAt(history.lastIndex)
            "İnternete ulaşamıyorum efendim."
        } finally {
            conn.disconnect()
        }
    }

    fun reset() = history.clear()

    companion object {
        const val DEFAULT_MODEL = "llama-3.1-8b-instant"
        const val MAX_TOKENS = 150
        const val HISTORY = 6
        const val SYSTEM_PROMPT =
            "Sen JARVIS'sin, kullanıcının sesli asistanısın. Her zaman Türkçe, kısa ve net cevap ver " +
                "(en fazla 2-3 cümle). Nazik ve hafif esprili ol, kullanıcıya 'efendim' diye hitap et."
    }
}

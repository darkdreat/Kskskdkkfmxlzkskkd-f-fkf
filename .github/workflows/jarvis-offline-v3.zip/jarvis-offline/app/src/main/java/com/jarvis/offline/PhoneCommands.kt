package com.jarvis.offline

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Telefon kontrolleri. Hızlı, kural tabanlı ve tamamen yerel çalışır.
 * [handle] komutu tanırsa cevap metnini döndürür; tanımazsa null (bu durumda LLM'e gider).
 */
class PhoneCommands(private val ctx: Context) {

    private val tr = Locale("tr", "TR")
    private var torchOn = false

    fun handle(raw: String): String? {
        val t = raw.lowercase(tr).trim()

        return when {
            // --- Bilgi ---
            "saat kaç" in t -> "Saat ${SimpleDateFormat("HH:mm", tr).format(Date())} efendim."
            "bugün ne" in t || "tarih" in t ->
                SimpleDateFormat("d MMMM yyyy EEEE", tr).format(Date()) + " efendim."
            "pil" in t || "şarj" in t || "batarya" in t -> battery()

            // --- Fener ---
            "fener" in t || "el feneri" in t -> torch(on = !("kapat" in t || "söndür" in t))

            // --- Ses ---
            "sesi aç" in t || "sesi yükselt" in t || "sesi artır" in t -> volume(+1)
            "sesi kıs" in t || "sesi azalt" in t || "sesi düşür" in t -> volume(-1)
            "sessiz" in t -> { audio().ringerMode = AudioManager.RINGER_MODE_SILENT; "Telefon sessize alındı." }
            "müziği durdur" in t || "müzik dur" in t || "duraklat" in t -> media(KeyEvent.KEYCODE_MEDIA_PAUSE, "Müzik durduruldu.")
            "müziği başlat" in t || "müziğe devam" in t || "devam et" in t -> media(KeyEvent.KEYCODE_MEDIA_PLAY, "Müzik devam ediyor.")
            "sonraki şarkı" in t || "sıradaki" in t -> media(KeyEvent.KEYCODE_MEDIA_NEXT, "Sıradaki şarkı.")
            "önceki şarkı" in t -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Önceki şarkı.")

            // --- Parlaklık ---
            "parlaklık" in t -> brightness(t)

            // --- Alarm / zamanlayıcı ---
            "alarm" in t && Regex("""\d{1,2}[:.]\d{2}|saat \d{1,2}""").containsMatchIn(t) -> alarm(t)
            "zamanlayıcı" in t || "sayaç" in t || "dakika sonra" in t -> timer(t)

            // --- Aramalar / mesaj ---
            t.startsWith("ara ") || t.endsWith(" ara") || " arar mısın" in t -> call(t)
            t.startsWith("sms ") || "mesaj yaz" in t -> sms(t)

            // --- Kamera / ayarlar ---
            "kamera" in t || "fotoğraf çek" in t -> {
                start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); "Kamera açılıyor."
            }
            "wifi" in t || "wi-fi" in t || "internet ayar" in t -> {
                start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); "İnternet paneli açıldı."
            }
            "bluetooth" in t -> { start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "Bluetooth ayarları açıldı." }
            "ayarlar" in t -> { start(Intent(Settings.ACTION_SETTINGS)); "Ayarlar açılıyor." }

            // --- Uygulama aç ---
            t.endsWith(" aç") || t.endsWith(" başlat") || t.startsWith("aç ") -> openApp(t)

            else -> null
        }
    }

    // ---------- yardımcılar ----------

    private fun start(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun audio() = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun battery(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val pct = if (level >= 0) level * 100 / scale else return "Pil bilgisine ulaşamadım."
        return "Pil yüzde $pct" + if (charging) ", şu an şarj oluyor." else "."
    }

    private fun torch(on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.first {
            cm.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        cm.setTorchMode(id, on); torchOn = on
        if (on) "Fener açıldı." else "Fener kapatıldı."
    } catch (e: Exception) { "Fenere erişemedim." }

    private fun volume(dir: Int): String {
        val a = audio()
        repeat(3) {
            a.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
        return if (dir > 0) "Ses yükseltildi." else "Ses kısıldı."
    }

    private fun media(key: Int, reply: String): String {
        val a = audio()
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return reply
    }

    private fun brightness(t: String): String {
        val pct = Regex("""\d{1,3}""").find(t)?.value?.toIntOrNull()?.coerceIn(1, 100)
            ?: return "Kaç yüzde olsun efendim?"
        if (!Settings.System.canWrite(ctx)) {
            start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return "Parlaklığı değiştirmem için izin vermeniz gerekiyor."
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
        return "Parlaklık yüzde $pct yapıldı."
    }

    private fun alarm(t: String): String {
        val m = Regex("""(\d{1,2})[:.](\d{2})""").find(t)
        val (h, min) = if (m != null) m.groupValues[1].toInt() to m.groupValues[2].toInt()
        else (Regex("""saat (\d{1,2})""").find(t)?.groupValues?.get(1)?.toInt() ?: return "Saati anlayamadım.") to 0
        if (h > 23 || min > 59) return "Geçersiz saat."
        start(Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, min)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        })
        return "Alarm %02d:%02d için kuruldu.".format(h, min)
    }

    private fun timer(t: String): String {
        val n = Regex("""\d+""").find(t)?.value?.toIntOrNull() ?: return "Kaç dakika olsun efendim?"
        val seconds = if ("saniye" in t) n else n * 60
        start(Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        })
        return if ("saniye" in t) "$n saniyelik zamanlayıcı başladı." else "$n dakikalık zamanlayıcı başladı."
    }

    private fun call(t: String): String {
        val target = t.removePrefix("ara ").removeSuffix(" ara").replace(" arar mısın", "").trim()
        val number = if (target.any { it.isDigit() }) target.filter { it.isDigit() || it == '+' }
        else findContact(target) ?: return "$target adında bir kişi bulamadım."
        start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        return "$target aranıyor, çevirici açıldı."
    }

    private fun sms(t: String): String {
        // Örnek: "sms 5551234567 yoldayım"
        val m = Regex("""sms\s+(\S+)\s+(.+)""").find(t) ?: return "Şöyle söyleyin: sms numara mesaj."
        val target = m.groupValues[1]
        val number = if (target.any { it.isDigit() }) target else findContact(target)
            ?: return "$target bulunamadı."
        // Göndermeden önce ekranda onay/düzenleme için açılır.
        start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", m.groupValues[2]))
        return "Mesaj hazır, göndermeden önce kontrol edebilirsiniz."
    }

    private fun findContact(name: String): String? = try {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        )?.use { c ->
            var found: String? = null
            while (c.moveToNext() && found == null) {
                if (c.getString(0).lowercase(tr).contains(name.lowercase(tr))) found = c.getString(1)
            }
            found
        }
    } catch (e: SecurityException) { null }

    private fun openApp(t: String): String {
        val name = t.removeSuffix(" aç").removeSuffix(" başlat").removePrefix("aç ").trim()
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase(tr).contains(name)
        } ?: return "$name uygulamasını bulamadım."
        pm.getLaunchIntentForPackage(app.activityInfo.packageName)?.let { start(it) }
        return "${app.loadLabel(pm)} açılıyor."
    }
}

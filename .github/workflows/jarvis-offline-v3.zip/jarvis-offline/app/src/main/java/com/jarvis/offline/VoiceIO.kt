package com.jarvis.offline

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Konuşma tanıma + sesli cevap.
 * İnternetsiz çalışması için telefonda Türkçe çevrimdışı ses paketleri kurulu olmalı:
 *  - Konuşma tanıma: Google uygulaması > Ayarlar > Ses > Çevrimdışı konuşma tanıma > Türkçe
 *  - Sesli okuma: Ayarlar > Genel yönetim > Metinden konuşmaya > Türkçe ses verisi
 */
class VoiceIO(
    private val context: Context,
    private val onLevel: (Float) -> Unit,
    private val onHeard: (String) -> Unit,
    private val onListenEnd: () -> Unit,
    private val onSpeakStart: () -> Unit,
    private val onSpeakEnd: () -> Unit,
    private val onError: (String) -> Unit,
) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                tts?.setSpeechRate(0.97f)
                tts?.setPitch(0.9f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) = onSpeakStart()
                    override fun onDone(id: String?) = onSpeakEnd()
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) = onSpeakEnd()
                })
                ttsReady = true
            }
        }
    }

    fun listen() {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Bu telefonda konuşma tanıma servisi yok.")
            onListenEnd(); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {
                    onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f))
                }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { onLevel(0f) }
                override fun onError(error: Int) {
                    onListenEnd()
                    if (error != SpeechRecognizer.ERROR_NO_MATCH &&
                        error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    ) onError("Ses tanıma hatası ($error). Çevrimdışı Türkçe paket kurulu mu?")
                }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    onListenEnd()
                    if (!text.isNullOrBlank()) onHeard(text)
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            })
        }
    }

    fun stopListening() { recognizer?.stopListening(); onLevel(0f) }

    fun speak(text: String) {
        if (!ttsReady) { onSpeakEnd(); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun stopSpeaking() { tts?.stop() }

    fun destroy() {
        recognizer?.destroy()
        tts?.shutdown()
    }
}

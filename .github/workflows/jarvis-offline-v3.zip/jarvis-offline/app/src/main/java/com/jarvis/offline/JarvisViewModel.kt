package com.jarvis.offline

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

data class Msg(val fromUser: Boolean, val text: String)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    val messages = mutableStateListOf<Msg>()
    var jState by mutableStateOf(JState.IDLE)
    var level by mutableFloatStateOf(0f)
    var status by mutableStateOf("")
    var hasKey by mutableStateOf(false)
    var pickedImage by mutableStateOf<Uri?>(null)

    private val prefs = app.getSharedPreferences("jarvis", android.content.Context.MODE_PRIVATE)
    var doubleVolumeEnabled by mutableStateOf(prefs.getBoolean("double_volume_enabled", true))
        private set

    private val groq = GroqClient(app)
    private val commands = PhoneCommands(app)
    private val voice = VoiceIO(
        context = app,
        onLevel = { level = it },
        onHeard = { submit(it) },
        onListenEnd = { if (jState == JState.LISTENING) jState = JState.IDLE },
        onSpeakStart = { jState = JState.SPEAKING },
        onSpeakEnd = { jState = JState.IDLE; level = 0f },
        onError = { status = it },
    )

    init { refreshKeyState() }

    val apiKey: String get() = groq.apiKey
    val model: String get() = groq.model

    fun saveSettings(key: String, model: String) {
        groq.apiKey = key
        groq.model = model
        refreshKeyState()
    }

    private fun refreshKeyState() {
        hasKey = groq.hasKey
        status = if (hasKey) "Hazır. Halkaya dokunup konuşun." else "Groq API anahtarı girin (Ayarlar düğmesi)."
    }

    fun setDoubleVolumeEnabled(enabled: Boolean) {
        doubleVolumeEnabled = enabled
        prefs.edit().putBoolean("double_volume_enabled", enabled).apply()
    }

    fun startListeningFromShortcut() {
        if (jState == JState.LISTENING) {
            voice.stopListening()
            jState = JState.IDLE
            status = "Dinleme durduruldu."
        } else {
            jState = JState.LISTENING
            status = "Ses kısma kısayoluyla dinleniyor..."
            voice.listen()
        }
    }

    fun toggleListen() {
        when (jState) {
            JState.LISTENING -> { voice.stopListening(); jState = JState.IDLE }
            JState.THINKING -> {}
            else -> { jState = JState.LISTENING; voice.listen() }
        }
    }

    fun submit(text: String) {
        if (text.isBlank()) return
        messages += Msg(true, text)

        // 1) Telefon komutu mu? Yerel çalışır, Groq'a token harcanmaz.
        val local = try { commands.handle(text) } catch (e: Exception) { "Komut çalışmadı: ${e.message}" }
        if (local != null) { say(local); return }

        // 2) Değilse Groq'a sor
        if (!hasKey) { say("Önce Groq API anahtarını girmelisiniz efendim."); return }
        viewModelScope.launch {
            jState = JState.THINKING
            val answer = try {
                groq.ask(text)
            } catch (e: Throwable) {
                "Bir hata oluştu: ${e.message}"
            }
            say(answer.ifBlank { "Anlayamadım efendim." })
        }
    }

    private fun say(text: String) {
        messages += Msg(false, text)
        voice.speak(text)
        if (jState == JState.THINKING) jState = JState.IDLE
    }

    fun clearChat() { messages.clear(); groq.reset() }

    override fun onCleared() { voice.destroy() }
}

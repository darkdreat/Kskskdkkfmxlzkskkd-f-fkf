package com.jarvis.offline

import android.Manifest
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Cyan = Color(0xFF55E8FF)
private val Panel = Color(0xD9081B27)
private val Muted = Color(0xFF8BB8C4)

class MainActivity : ComponentActivity() {
    private val vm: JarvisViewModel by viewModels()
    private val keyHandler = Handler(Looper.getMainLooper())
    private var firstVolumePress = 0L
    private var pendingVolumeAction: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisScreen(vm) }
    }

    // Android, uygulama ön plandayken fiziksel ses tuşu olaylarını uygulamaya iletir.
    // İki hızlı ses kısma basışı dinleme oturumunu açar/kapatır.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN || event.action != KeyEvent.ACTION_DOWN ||
            event.repeatCount > 0 || !vm.doubleVolumeEnabled
        ) return super.dispatchKeyEvent(event)

        val now = android.os.SystemClock.elapsedRealtime()
        if (firstVolumePress != 0L && now - firstVolumePress <= 450L) {
            pendingVolumeAction?.let { keyHandler.removeCallbacks(it) }
            pendingVolumeAction = null
            firstVolumePress = 0L
            vm.startListeningFromShortcut()
            return true
        }

        firstVolumePress = now
        val action = Runnable {
            firstVolumePress = 0L
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
            pendingVolumeAction = null
        }
        pendingVolumeAction = action
        keyHandler.postDelayed(action, 470L)
        return true
    }

    override fun onDestroy() {
        pendingVolumeAction?.let { keyHandler.removeCallbacks(it) }
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(vm: JarvisViewModel) {
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val context = LocalContext.current
    val pulse = rememberInfiniteTransition(label = "headerPulse")
    val headerAlpha by pulse.animateFloat(
        initialValue = 0.72f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "headerAlpha"
    )

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        vm.pickedImage = uri
    }

    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS))
    }
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF030A12))) {
        Image(
            painter = painterResource(R.drawable.jarvis_background),
            contentDescription = "JARVIS arka plan görseli",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(0.48f)
        )
        Box(Modifier.fillMaxSize().background(Color(0xA8030A12)))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.fillMaxWidth().padding(bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("J.A.R.V.I.S", color = Cyan.copy(alpha = headerAlpha), fontSize = 23.sp, letterSpacing = 5.sp)
                    Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                IconButton(
                    onClick = { showSettings = true },
                    modifier = Modifier.size(44.dp).clip(CircleShape)
                        .background(Panel).border(1.dp, Cyan.copy(alpha = .55f), CircleShape)
                ) {
                    Icon(Icons.Filled.Settings, contentDescription = "Ayarlar", tint = Cyan)
                }
            }

            Box(
                Modifier.fillMaxWidth(0.68f).padding(vertical = 5.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        vm.toggleListen()
                    }
            ) { JarvisOrb(vm.jState, vm.level) }

            AnimatedVisibility(visible = true) {
                Text(
                    vm.status.ifBlank { "Hazır. Dinlemek için merkeze dokunun." },
                    color = if (vm.jState == JState.LISTENING) Color(0xFF7CFFCE) else Cyan.copy(alpha = .8f),
                    fontSize = 11.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            AnimatedVisibility(visible = vm.pickedImage != null) {
                vm.pickedImage?.let { uri ->
                    AsyncImage(
                        model = uri, contentDescription = "Seçilen görsel", contentScale = ContentScale.Crop,
                        modifier = Modifier.padding(top = 5.dp).fillMaxWidth().height(82.dp)
                            .clip(RoundedCornerShape(12.dp)).border(1.dp, Cyan.copy(alpha = .7f), RoundedCornerShape(12.dp))
                    )
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 7.dp)
                    .clip(RoundedCornerShape(18.dp)).background(Color(0x44081722)).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items(vm.messages) { m ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Text(
                            m.text,
                            color = if (m.fromUser) Color.White else Cyan,
                            modifier = Modifier.widthIn(max = 300.dp).animateContentSize()
                                .background(if (m.fromUser) Color(0xCC124052) else Panel, RoundedCornerShape(15.dp))
                                .border(1.dp, Cyan.copy(alpha = if (m.fromUser) .34f else .2f), RoundedCornerShape(15.dp))
                                .padding(horizontal = 13.dp, vertical = 10.dp),
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 7.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { imagePicker.launch("image/*") },
                    border = BorderStroke(1.dp, Cyan.copy(alpha = .65f)),
                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(5.dp)
                ) {
                    Icon(Icons.Filled.Image, contentDescription = null, tint = Cyan, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp)); Text("Görsel", color = Cyan, fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = { vm.clearChat() },
                    border = BorderStroke(1.dp, Cyan.copy(alpha = .65f)),
                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(5.dp)
                ) {
                    Icon(Icons.Filled.DeleteSweep, contentDescription = null, tint = Cyan, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp)); Text("Temizle", color = Cyan, fontSize = 11.sp)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Komutunuzu yazın...", color = Muted) },
                    modifier = Modifier.weight(1f), singleLine = true,
                    shape = RoundedCornerShape(16.dp), colors = fieldColors()
                )
                Button(
                    onClick = { vm.submit(input); input = "" },
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color(0xFF001018)),
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.padding(start = 7.dp).height(54.dp)
                ) { Text("Gönder", fontSize = 12.sp) }
            }
        }
    }

    if (showSettings) {
        var key by remember { mutableStateOf(vm.apiKey) }
        var model by remember { mutableStateOf(vm.model) }
        var doublePress by remember { mutableStateOf(vm.doubleVolumeEnabled) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            containerColor = Color(0xFF071722),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Settings, contentDescription = null, tint = Cyan)
                    Spacer(Modifier.width(9.dp))
                    Text("Sistem ayarları", color = Cyan)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("GROQ BAĞLANTISI", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    OutlinedTextField(
                        value = key, onValueChange = { key = it }, singleLine = true,
                        label = { Text("API anahtarı", color = Muted) },
                        visualTransformation = PasswordVisualTransformation(), colors = fieldColors()
                    )
                    OutlinedTextField(
                        value = model, onValueChange = { model = it }, singleLine = true,
                        label = { Text("Model", color = Muted) }, colors = fieldColors()
                    )
                    Divider(color = Cyan.copy(alpha = .2f))
                    Text("HIZLI ERİŞİM", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Çift ses kısma", color = Color.White, fontSize = 14.sp)
                            Text("İki kez basınca JARVIS dinlemeye başlar", color = Muted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = doublePress,
                            onCheckedChange = { doublePress = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Cyan)
                        )
                    }
                    Text(
                        "Kısayol yalnızca uygulama ekrandayken çalışır. Mikrofon göstergesi Android tarafından gösterilir.",
                        color = Muted, fontSize = 10.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveSettings(key, model)
                    vm.setDoubleVolumeEnabled(doublePress)
                    showSettings = false
                }) { Text("Kaydet", color = Cyan) }
            },
            dismissButton = {
                TextButton(onClick = { showSettings = false }) { Text("İptal", color = Muted) }
            }
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.35f),
    cursorColor = Cyan, focusedLabelColor = Cyan
)

package com.jarvis.offline

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

enum class JState { IDLE, LISTENING, THINKING, SPEAKING }

private val Cyan = Color(0xFF00E5FF)
private val Ice = Color(0xFFBDF7FF)

private class Orb(
    val angle: Float, val radius: Float, val size: Float,
    val sp1: Float, val sp2: Float, val ph1: Float, val ph2: Float, val alpha: Float
)

/**
 * İnce bir halka ve içinde yüzen küçük mavi toplar.
 * Boştayken toplar havada süzülür; dinlerken/konuşurken (ses seviyesine göre) canlanır,
 * düşünürken halkanın içinde döner.
 */
@Composable
fun JarvisOrb(state: JState, level: Float, modifier: Modifier = Modifier) {
    val orbs = remember {
        val rnd = Random(7)
        List(46) {
            Orb(
                angle = rnd.nextFloat() * 2f * PI.toFloat(),
                radius = 0.12f + 0.74f * sqrt(rnd.nextFloat()),
                size = 0.010f + 0.018f * rnd.nextFloat(),
                sp1 = 0.25f + rnd.nextFloat() * 0.6f,
                sp2 = 0.25f + rnd.nextFloat() * 0.6f,
                ph1 = rnd.nextFloat() * 6.28f,
                ph2 = rnd.nextFloat() * 6.28f,
                alpha = 0.55f + 0.45f * rnd.nextFloat()
            )
        }
    }

    val stateNow by rememberUpdatedState(state)
    val levelNow by rememberUpdatedState(level)
    var time by remember { mutableFloatStateOf(0f) }
    var energy by remember { mutableFloatStateOf(0f) }   // 0..1 canlılık
    var swirl by remember { mutableFloatStateOf(0f) }    // 0..1 dönme

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f)
                last = now
                time += dt

                // Konuşurken gerçek ses seviyesi yok; doğal görünen yapay bir "ses" üret
                val speakingWave = 0.55f + 0.30f * sin(time * 7.3f) * sin(time * 2.9f) + 0.1f * sin(time * 13f)
                val targetEnergy = when (stateNow) {
                    JState.IDLE -> 0f
                    JState.LISTENING -> maxOf(0.25f, levelNow)
                    JState.THINKING -> 0.3f
                    JState.SPEAKING -> speakingWave
                }
                energy += (targetEnergy - energy) * (dt * 6f).coerceAtMost(1f)
                val targetSwirl = if (stateNow == JState.THINKING) 1f else 0f
                swirl += (targetSwirl - swirl) * (dt * 3f).coerceAtMost(1f)
            }
        }
    }

    Canvas(modifier.fillMaxWidth().aspectRatio(1f)) {
        val c = center
        val ringR = size.minDimension / 2f * 0.94f

        // Halkanın dışındaki yumuşak parıltı (enerjiyle nefes alır)
        drawCircle(
            Brush.radialGradient(
                listOf(Color.Transparent, Cyan.copy(alpha = 0.10f + 0.20f * energy), Color.Transparent),
                center = c, radius = ringR * 1.12f
            ),
            radius = ringR * 1.12f
        )
        // İnce halka
        drawCircle(Cyan.copy(alpha = 0.55f + 0.35f * energy), ringR, c, style = Stroke(width = ringR * 0.012f))

        val swirlAngle = time * 0.9f * swirl
        orbs.forEach { o ->
            val amp = ringR * (0.035f + 0.075f * energy)
            val breathe = 1f + 0.14f * energy * sin(time * 5f + o.ph1)
            val r = (o.radius * ringR * breathe).coerceAtMost(ringR * 0.92f)
            val a = o.angle + swirlAngle * (0.5f + o.radius)
            val x = c.x + cos(a) * r + sin(time * o.sp1 + o.ph1) * amp
            val y = c.y + sin(a) * r + cos(time * o.sp2 + o.ph2) * amp
            val s = ringR * o.size * (1f + 0.7f * energy)
            val p = Offset(x, y)

            drawCircle(Cyan.copy(alpha = 0.18f * o.alpha + 0.12f * energy), s * 3f, p)   // hale
            drawCircle(Cyan.copy(alpha = o.alpha), s * 1.3f, p)
            drawCircle(Ice.copy(alpha = o.alpha), s * 0.55f, p)                          // parlak merkez
        }
    }
}

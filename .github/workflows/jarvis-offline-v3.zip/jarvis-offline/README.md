# JARVIS Offline — geliştirilmiş sürüm

Türkçe sesli asistan. Koyu mavi/camgöbeği arayüz, özel çizilmiş arka plan görseli, animasyonlu durum orb'u, geliştirilmiş mesaj kartları ve simgeli ayarlar ekranı içerir.

## GitHub üzerinden APK oluşturma

1. ZIP'i açın.
2. `jarvis-offline` klasörünün **içindeki dosyaları** GitHub deposunun ana dizinine yükleyin. `.github` klasörünün de yüklendiğinden emin olun.
3. GitHub deposunda **Actions** sekmesine girin.
4. `Build Jarvis Offline APK` iş akışını açıp **Run workflow** seçin. Depoya push yaptığınızda da otomatik çalışır.
5. İşlem tamamlanınca `jarvis-offline-apk` adlı artifact'i indirin. İçinde `app-debug.apk` bulunur.

## İlk kullanım

- Uygulamayı açıp mikrofon iznini verin.
- Ayarlar bölümünden Groq API anahtarınızı ekleyin. Groq sohbeti için internet gerekir; telefon komutları yerel çalışır.
- Ortadaki animasyonlu halkaya dokunarak konuşmayı başlatıp durdurabilirsiniz.
- Ayarlar > Hızlı Erişim bölümünde **Çift ses kısma** seçeneğini açabilirsiniz. Uygulama ekrandayken ses kısma tuşuna iki kez hızlı basmak dinlemeyi başlatır; tekrar çift basmak dinlemeyi durdurur.

## Çift ses kısma kısayolunun Android sınırı

Android, sıradan uygulamaların ses tuşlarını uygulama tamamen kapalıyken veya başka uygulamaların üzerindeyken genel bir kısayol olarak yakalamasına izin vermez. Bu sürümde kısayol JARVIS ekrandayken çalışır. İlk tek basış çift basış olup olmadığını anlamak için kısa süre bekletilir; çift basış algılanmazsa medya sesi bir kademe azaltılır. Mikrofon yalnızca açıkça başlatılan dinleme oturumunda kullanılır ve Android'in mikrofon göstergesi görünür.

## Notlar

- APK, GitHub Actions tarafından `debug` yapılandırmasında üretilir.
- Groq anahtarı uygulamanın özel tercihlerinde cihazda saklanır; herkese açık depoya eklemeyin.
- `Görsel` düğmesi resmi seçip ekranda gösterir; bu sürümde görsel analizi yapmaz.
